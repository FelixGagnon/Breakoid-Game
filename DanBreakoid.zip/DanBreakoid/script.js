var canvas = document.getElementById("myCanvas");
var ctx = canvas.getContext("2d");
var scoreInput = document.getElementById("score_input");
var lifesHolder = document.getElementById("lifes_sprite");
var startBtn = document.getElementById("startBtn");
var gameWrapper = document.getElementById("game_wrapper");

var paused = false;
var mouse = false;
let loop;
var gameStop = true;
var brickLeft = 32;
var level = 0;
var score = 0;
var lifeLost = 0;
var ballSize = 24;
var paddleHeight = 20;
var paddleWidth = 115;
var paddleX = (canvas.width - paddleWidth)/2;
var x = (canvas.width/2)-(ballSize/2);
var y = canvas.height - 40;
var dx = 3;
var dy = -3;
var rightPressed = false;
var leftPressed = false;
var spacePressed = false;
var brickRowCount = 4;
var brickColumnCount = 8;
var brickWidth = 76;
var brickHeight = 28;
var brickPadding = 10;
var brickOffsetTop = 20;
var brickOffsetLeft = 20;
var bricks = [];


window.addEventListener('keydown', pauseGameKeyHandler, false);
document.addEventListener("keydown", keyDownHandler, false);
document.addEventListener("keyup", keyUpHandler, false);
canvas.addEventListener("mousemove", mouseMoveHandler, false);

anime({
    targets: '.canvas',
    translateX: 250,
    direction: 'reverse',
    easing: 'easeInOutSine'
  });

function onStart() {
    loop = requestAnimationFrame(draw);
  }
  

anime({
    targets: startBtn,
    scale: 1.5,
    direction: 'alternate',
    loop: true,
    easing: 'spring(1, 80, 30, 0)'
  });


function bricksIni() {
    bricks = [];
    for(var c=0; c<brickColumnCount; c++) {
        bricks[c] = [];
        for(var r=0; r<brickRowCount; r++) {
            bricks[c][r] = { x: 0, y: 0, status: 1 };
        }
    }
} 



    
var onLife, zeroLife;
function printScore() {
    scoreInput.innerHTML = score;
}
function printLife() {
    clearInterval(onLife);
    clearInterval(zeroLife);
    if (lifeLost == 3){
        lifesHolder.style.backgroundPositionX = "268px";
    }
    if (lifeLost == 2){
        lifesHolder.style.backgroundPositionX = "536px";
        oneLife = setInterval(function(){lifesHolder.style.backgroundPositionX = "268px";}, 1000);
        setTimeout(function() {zeroLife = setInterval(function(){lifesHolder.style.backgroundPositionX = "536px";}, 1000)}, 500);
    }
    if (lifeLost == 1){
        lifesHolder.style.backgroundPositionX = "804px";
    }
    if (lifeLost == 0){
        lifesHolder.style.backgroundPositionX = "0px";
    }  
}


function drawBricks() {
    for(var c=0; c<brickColumnCount; c++) {
        for(var r=0; r<brickRowCount; r++) {
            if(bricks[c][r].status == 1) {
                var brickX = (c*(brickWidth+brickPadding))+brickOffsetLeft;
                var brickY = (r*(brickHeight+brickPadding))+brickOffsetTop;
                bricks[c][r].x = brickX;
                bricks[c][r].y = brickY;
                ctx.beginPath();
                ctx.rect(brickX, brickY, brickWidth, brickHeight);
                ctx.fillStyle = "#03f800";
                ctx.fill();
                ctx.closePath();
            }    
        }
    }

}

function animateScore() {
    if(score === 100 || score === 200 || score === 300 || score === 400 || score === 500 || score === 600 || score === 700 || score === 800 || score === 900 || score === 1000) {
        anime({
            targets: scoreInput,
            scale: 1.5,
            direction: 'alternate',
            easing: 'spring(1, 80, 30, 0)'
          });
    }
}

function animateLastLife() {
    if (lifeLost == 2) {
        anime({
            targets: lifesHolder,
            opacity: 35,
            direction: 'alternate',
            loop: true,
            easing: 'spring(10, 80, 30, 40)'
          });
    }
}

function isWin() {
    if (brickLeft == 0) {
        level++;
        canvas.style.backgroundImage="url(images/levelcompleted.jpg)"
        reset();
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        draw();
        gameStop = true; 
        paused = true;
        setTimeout(function(){
            if (level == 2) {
                canvas.style.backgroundImage="url(images/retro_bg2.jpg)";
                paused = false;
                bricksIni();
                draw();  
            }   
            if (level == 3) {
                    canvas.style.backgroundImage="url(images/retro_bg3.jpg)";
                    bricksIni();
                    paused = false;
                    draw();
            }
            if (level == 4) {
                    canvas.style.backgroundImage="url(images/gameover.jpg)";
                    startBtn.style.display="block";
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    cancelAnimationFrame(loop);
                    paused = true;
            }
        }, 5000);
        
    } 
}
    

function collisionDetection() {
    for(var c=0; c<brickColumnCount; c++) {
        for(var r=0; r<brickRowCount; r++) {
            var b = bricks[c][r];
            if(b.status == 1) {
                if(x > b.x && x < b.x+brickWidth && y > b.y && y < b.y+brickHeight) {
                    dy = -dy;
                    b.status = 0;
                    score += 10;
                    brickLeft--;
                    printScore();
                    animateScore();
                    isWin();
                }
            }
        }
    }
}





function mouseMoveHandler(e) {
    var relativeX = e.offsetX;
    
    if (relativeX > paddleWidth/2 && relativeX < canvas.width - (paddleWidth/2)) {
        paddleX = relativeX - paddleWidth/2;
        if (gameStop) {
            x = relativeX - (ballSize/2);
        }
    }
    if (relativeX < paddleWidth/2) {
        paddleX = 0;
        if (gameStop) {
            x = (paddleWidth/2) - (ballSize/2);
        }
    }
    if (relativeX > canvas.width - (paddleWidth/2)) {
        paddleX = canvas.width - paddleWidth;
        if (gameStop) {
            x = canvas.width - (paddleWidth/2) - (ballSize/2);
        }
    }
}

//key pressed handler
function keyDownHandler(e) {
    if(e.key == "d") {
        rightPressed = true;
    }
    else if(e.key == "a") {
        leftPressed = true;
    }
    else if(e.key == " ") {
        spacePressed = true;
    }
}



function pauseGameKeyHandler(e) {
    if (!gameStop) {
        var keyCode = e.keyCode;
        switch(keyCode){
            case 32: 
                togglePause();
            break;
        }
    }
}

function togglePause() {
    paused = !paused;
    draw();
}



//key release handler
function keyUpHandler(e) {
    if(e.key == "d") {
        rightPressed = false;
    }
    else if(e.key == "a") {
        leftPressed = false;
    }
    else if(e.key == " ") {
        spacePressed = false;
    }
}

//Draw the paddle
function drawPaddle() {
    var paddleImage = new Image(paddleWidth, paddleHeight);
    paddleImage.src = 'images/paddle.png';
    ctx.drawImage(paddleImage, paddleX, canvas.height-20);
}

//Draw the ball
function drawBall() {
    var ballImage = new Image(ballSize, ballSize);
    ballImage.src = 'images/ball.png';
    ctx.drawImage(ballImage, x, y);
}

//reset the game
function reset() {
    gameStop = true;
    paddleX = (canvas.width - paddleWidth)/2;
    x = (canvas.width - ballSize)/2;
    y = canvas.height-40;
    dx = 3;
    dy = -3;
    rightPressed = false;
    leftPressed = false;
}



function newGame() {
    canvas.style.backgroundImage="url(images/retro_bg1.jpg)";
    score = 0;
    printScore();
    lifeLost = 0;
    lifesHolder.style.backgroundPositionX = "0px";
    printLife();
    printScore;
    bricksIni();
    reset();
}



//setup game loop
function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawPaddle();
        drawBall();
        drawBricks();
        collisionDetection();
            if (rightPressed) {
                paddleX += 5;
                if (paddleX + paddleWidth > canvas.width){
                    paddleX = canvas.width - paddleWidth;
                } 
                if (gameStop) {
                    x +=5;
                    if (x + (paddleWidth/2) + (ballSize/2) > canvas.width) {
                        x = canvas.width - (paddleWidth/2) - (ballSize/2);
                    }
                }
            } 
            if (leftPressed) {
                paddleX -= 5;
                if (paddleX < 0){
                    paddleX = 0;
                } 
                if (gameStop) {
                    x -=5;
                    if (x - (paddleWidth/2) < 0) {
                        x = (paddleWidth/2) - (ballSize/2);
                    }  
                }
            } 
            if (spacePressed) {
                    gameStop = false;
            }
            if (!gameStop) {
                if (x + dx > canvas.width-ballSize || x + dx < 0) {
                    dx = -dx;
                }
                if (y + dy < 0) {
                    dy = -dy;
                }
                else if (y + dy > canvas.height - 40) {
                    if(x > paddleX && x < paddleX + paddleWidth) {
                        dy = -dy;
                    }
                    else {
                        lifeLost++;
                        console.log(lifeLost);
                        printLife();
                        if (lifeLost < 3 ) {
                            reset();
                        } 
                        else {
                            canvas.style.backgroundImage="url(images/gameover.jpg)";
                            startBtn.style.display="block";
                            ctx.clearRect(0, 0, canvas.width, canvas.height);
                            cancelAnimationFrame(loop);
                            paused = true;
                        } 
                    }
                }
                x += dx;
                y += dy;
            }
        
    if (!paused) {      
    loop = requestAnimationFrame(draw);
    }
}

function loading() {
    canvas.style.backgroundImage="url(images/bg_niveau1.png)";
    var loadingWrapper = document.getElementById("loading_wrapper");
    var loading = document.getElementById("loading");
    loadingWrapper.style.display= "flex";
    setTimeout(function(){loadingWrapper.style.display= "none";}, 4000);
    anime({
        targets: loading,
        keyframes: [
            {rotate: 90},
            {rotate: 180},
            {rotate: 270},
            {rotate: 360}
          ],
        duration: 4000,
        easing: 'easeOutElastic(1, .8)',
      }); 
}


//start game loop
startBtn.addEventListener("click",  e => {
    paused = false;
    level = 1;
    startBtn.style.display="none";
    loading();
    setTimeout(function(){newGame();onStart();}, 4000); 
});
